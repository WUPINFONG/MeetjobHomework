# -*- coding: utf-8 -*-
"""
Created on Thu Oct 27 19:34:06 2022

@author: perry
"""
from flask import Flask,render_template,request,url_for,redirect
import db


app=Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")



@app.route('/contact')
def contact():
    return render_template('contact.html',)   
@app.route("/addcontact",methods=['POST'])
def addcontact():
    if request.method=="POST":
        name=request.form.get('username')
        email=request.form.get('Email')
        suject=request.form.get('Subject')
        content=request.form.get('Message')
        sql="insert into message (name,email,subject,content)values('{}','{}','{}','{}')".format(name,email,suject,content)
        cursor=db.conn.cursor()
        cursor.execute(sql)
        db.conn.commit()
    return redirect(url_for('contact'))
@app.route('/about')
def about():
    return render_template("about.html")

@app.route('/service')
def service():
    return render_template("service.html")




app.run(debug=True,host='0.0.0.0',port='5566')